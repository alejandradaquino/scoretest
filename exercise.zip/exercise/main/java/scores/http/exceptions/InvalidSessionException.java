package scores.http.exceptions;

public class InvalidSessionException extends RuntimeException{
}
